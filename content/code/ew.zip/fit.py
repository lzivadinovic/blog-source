#!/usr/bin/env python3

import numpy as np
from scipy import interpolate as intp
from scipy import integrate as intg
import matplotlib.pyplot as plt
import matplotlib.ticker as plticker
from matplotlib.ticker import ScalarFormatter, FormatStrFormatter



class FixedOrderFormatter(ScalarFormatter):
    """Formats axis ticks using scientific notation with a constant order of
    magnitude"""
    def __init__(self, order_of_mag=0, useOffset=True, useMathText=False):
        self._order_of_mag = order_of_mag
        ScalarFormatter.__init__(self, useOffset=useOffset,
                                 useMathText=useMathText)
    def _set_orderOfMagnitude(self, range):
        """Over-riding this to avoid having orderOfMagnitude reset elsewhere"""
        self.orderOfMagnitude = self._order_of_mag


'''
UKRŠTENE REČI NE MOGU DA REŠIM,
NE PITAJ ME NIŠTA KILO GRANJA LEŠIM!
'''

x,y = np.loadtxt('linija.txt', unpack=True)
y=1-y

I=intp.interp1d(x,y, kind='cubic')

area=intg.simps(I(x),x)
print(area)
fig, ax = plt.subplots()


ax.plot(x, y, 'ob', label='Merenja')

ax.plot(x,I(x), '-r', label='Cubic Spline interpolacija')
ax.xaxis.set_major_formatter(FormatStrFormatter('%0.1f'))
ax.yaxis.set_major_formatter(FixedOrderFormatter(0))
ax.fill_between(x,I(x), facecolor='black', alpha=0.4)
plt.ylabel(r'$1-Flux$')
plt.xlabel(r'$Wavelenght [\dot{A}]$')
plt.ylim(-0.01,0.25)
plt.xlim(5395.76,5396.3)
asd=str(area)
ax.set_title("Ekvivalentna širina = " + asd[0:6])
ax.legend(loc=2)
plt.show()
